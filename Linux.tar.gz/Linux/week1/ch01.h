#include <sys/utsname.h>
#include <unistd.h>
#include <stdio.h>
#include "err_exit.h"
#include <sys/param.h>
#include <limits.h>