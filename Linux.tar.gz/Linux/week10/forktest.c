#include "ch10.h"
int main()
{
    pid_t pid[6];
    printf("parent :pid=%d,ppid=%d\n",getpid(),getppid());
    
    pid[1]=fork();
    if(pid[1]==0)
    {
        printf("son1 :pid=%d,ppid=%d\n",getpid(),getppid());
        exit(0);
    }
    if(pid[1]>0)
    {
        pid[2]=fork();
        if(pid[2]==0)
        {
            printf("son3 :pid=%d,ppid=%d\n",getpid(),getppid());
            exit(0);
        }
        if(pid[2]>0)
        {
            pid[3]=fork();
            if(pid[3]==0)
            {
                printf("son2 :pid=%d,ppid=%d\n",getpid(),getppid());
                pid[4]=fork();
                if(pid[4]==0)
                {
                    printf("grandson1 :pid=%d,ppid=%d\n",getpid(),getppid());
                    exit(0);
                }
                if(pid[4]>0)
                {
                    pid[5]=fork();
                    if(pid[5]==0)
                    {
                        printf("grandson2 :pid=%d,ppid=%d\n",getpid(),getppid());
                        exit(0);
                    }
                    wait(NULL);
                    wait(NULL);
                }
            }
            wait(NULL);
            wait(NULL);
            wait(NULL);
        }
    }
    return 0;
}