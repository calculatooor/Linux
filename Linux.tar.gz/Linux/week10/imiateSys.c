#include "ch10.h"
int main()
{
    pid_t pid;
    pid=fork();
    // exec();
    if(pid<0)
    {
        perror("fork failed!\n");
        exit(-1);
    }else if(pid==0){
        char *argv[]={"./test","hello",NULL};
        printf("child :pid=%d,ppid=%d,re=%d\n",getpid(),getppid(),pid);
        execve("./test",argv,NULL);
        sleep(10);
        exit(99);
    }else{
        int s,r;
        r=wait(&s);
        printf("parent :pid=%d,ppid=%d,r=%d,s=%d\n",getpid(),getppid(),r,s);
    }
    
}
