#include "ch02.h"
#include "y_or_n_ques.c"
int main(int argc,char *argv[])
{
    FILE *fd;
    fpos_t pos;
    if(!y_or_n_ques("Should we use append mode?"))
    {
        if((fd=fopen("Hole_file","w+"))==NULL)
            err_exit("fopen failed");
    }else{
        if((fd=fopen("Hole_file","a+"))==NULL)
            err_exit("fopen failed");
    }
    fputs("0123456789ABCDEFGHIJKLMN",fd);
    fseek(fd,0,SEEK_END);
    fgetpos(fd,&pos);
    printf("current file position is %ld\n",pos);
    fseek(fd,30,SEEK_END);//文件指针后移，制造30字节空洞
    fgetpos(fd,&pos);
    printf("Now we call fseek(fd,30,SEEK_END);"
        "current file position is %ld\n",pos);
    fputs("abcdefg",fd);
    printf("Now we wirte 7 bytes\"%s\"\n","abcdefg");
    fgetpos(fd,&pos);
    printf("current file position is %ld\n",pos);
    fclose(fd);
}