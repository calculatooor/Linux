#include "ch02.h"
int main(void)
{
    FILE *stream;
    char buf[80];
    printf("open and create test file\n");
    if((stream=fopen("test.dat","w"))==NULL)
        err_exit("fopen() failed");
    printf("write string to test.dat\n");
    fputs("Hello World!",stream);
    if((stream=freopen("test.dat","r",stream))==NULL)
        err_exit("freopen() failed");
    printf("read string from test.dat\n");
    fgets(buf,sizeof(buf),stream);
    printf("the string is \"%s\"\n",buf);
    fclose(stream);
}