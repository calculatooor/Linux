#include "ch02.h"
int main()
{
    float data[10];
    FILE *stream=fopen("test.dat","w+");
    puts("input two float number");
    //getchar();
    if(fread(&data[2],sizeof(float),2,stdin)!=2)
        perror("fread error");
        
    if(fwrite(&data[2],sizeof(float),2,stream)!=2)
        perror("fwrite error");
    fclose(stream);
    return 0;
}