#include "ch02.h"
#include "y_or_n_ques.c"
int main()
{
    char test[]="test\n";
    y_or_n_ques(test);
}