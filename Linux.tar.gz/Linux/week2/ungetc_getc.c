#include "ch02.h"
int main()
{
    FILE *stream=fopen("test.dat","r");
    char c;
    //提前读并 回退
    c=getc(stream);
    putchar(c);
    ungetc(c,stream);
    
    //正常读
    char *lineptr=NULL;
    size_t n=0;
    getline(&lineptr,&n,stream);
    puts(lineptr);
    
    return 0;
}