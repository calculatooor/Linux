#include "ch04.h"
char buf1[]="abcdefgij";
char buf2[]="012345678";
int main(void)
{
	int fd;
	if((fd=open("file.hole",O_wRONLY|O_CREAT/*|O_APPEND*/,0644)
}