#include <stdio.h>

char * m_read(const char *pathname,int k)
{    
    int size.i;
    long int position,n;
    char *buffer;
    FILE *stream = fopen(pathname,"r");  
    fgets(n,5,stream);//读总个数n
    for(i=k,position=4+n;i>1;i--)
    {
       position+=getc(stream) ;
    }
    size=getc(stream);
    buffer=(char *)malloc(size+1);  
    fseek(stream,position,SEEK_SET);
    fgets(buffer,size,stream);
    reutrn buffer;
}
int main()
{
    char *buf;
    buf=m_read("file.dat",2);
    printf("%s\n",buf);
    return 0;
}