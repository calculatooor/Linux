#include "ch06.h"
int main(int argc,char *argv[])
{
    if(argc>3) {
        printf("input over two number\n");
        exit(1);
    }
    if(argc<3){
       printf("input less two number\n"); 
       exit(1);
    } 
    printf("%d + %d = %d\n",atoi(argv[1]),atoi(argv[2]),atoi(argv[1])+atoi(argv[2]));
    return 0;
}