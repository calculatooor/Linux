#include "ch06.h"
//strace ./before
static void __attribute__((constructor)) before_main(void)
{
    printf("----Before Main --------\n");
}
//析构函数
static void __attribute__((destructor))after_main(void)
{
    printf("----After Main ------\n");
}
int main()
{
    printf("-------Main Funciton is Running!--------\n");
    return 0;
}