#include "ch06.h"
static void __attribute__((destructor))After_Main()
{
    printf("------after __attribute__-------\n");
}
void MyCallback()
{
    printf("------callback-----\n");
}
void MyCallback2()
{
    printf("------callback2-----\n");
}
void MyCallback3()
{
    printf("------callback3-----\n");
}
int main()
{
    atexit(MyCallback);
    atexit(MyCallback2);
    atexit(MyCallback3);
    while(1)
    {
        printf("-------main running-----\n");
        sleep(1);
    }
    printf("-----callback main finished-------\n");
    return 0;
}