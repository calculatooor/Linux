#include "ch06.h"
int main(int argc,char *argv[])
{
    printf("----main-----");
    // exit(0);
    // return 0;
    _exit(0);
}
