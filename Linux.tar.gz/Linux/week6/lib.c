#include "ch06.h"
void dynamic_lib_call(void)
{
    printf("-----dynamic_lib_call-----\n");
}