#include "ch06.h"
extern void dynamic_lib_call(void);
int main()
{
    dynamic_lib_call();
    return 0;
}