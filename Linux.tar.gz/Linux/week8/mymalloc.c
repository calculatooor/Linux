#include "ch08.h"
#include <malloc.h>
int main()
{
    int *pt=NULL;
    int i;
    for(i=1;i<1024;i++)
    {
        pt=(int *)malloc(i*1024*1024*sizeof(int));
        if(pt!=NULL)
        {
            printf("pt size:%dMB\n",malloc_usable_size(pt)/(1024*1024));
        }else{
            err_exit("malloc error");
        }
    }
}