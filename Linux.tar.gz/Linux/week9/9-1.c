#include "ch09.h"
char *env_init[]={"USER=stu","PATH=/study/Linux/week9",NULL};
int main()
{
    char *args[]={"mytest","hello","world!\n",NULL}; 
    // if(execve("mytest",args,env_init)==-1)
    if(execle("mytest","hello","world!\n",NULL,env_init)==-1)
    {
        // perror("execve!\n");
        perror("execle\n");
        exit(EXIT_FAILURE);
        
    }
    puts("Never get here!\n");
    exit(EXIT_SUCCESS);
}