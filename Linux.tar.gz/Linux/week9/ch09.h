#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <malloc.h>
#include <setjmp.h>
#include <errno.h>

#define INFILE "in.txt"
#define OUTFILE "out.txt"
#define MODE S_IRUSR|S_IWUSR|S_IRGRP|S_IWGRP|S_IROTH


#define err_exit(MESSAGE) (                \
    perror(MESSAGE),                       \
    exit(1)                                \
)                                            


