#include "ch09.h"

int main()
{
    pid_t pid=1,pid2=1,pid3=1;
    int fd_out;
    char buf[1024];
    memset(buf,0,1024);
    
    fd_out=open(OUTFILE,O_WRONLY|O_CREAT|O_TRUNC,MODE);
    pid=fork();
    pid2=fork();
    if(pid<0||pid2<0||pid3<0)
    {
        perror("Fork failed!\n");
        exit(-1);
    }else if(pid==0||pid2==0||pid3==0){
       if(pid==0)
       {
        printf("ppid:%d ,pid:%d buf:%s\n",getppid(),getpid(),buf);
        // sprintf(buf,"%d %s\n",getpid(),time());
        // write(fd_out,buf,strlen(buf));
        sleep(1);
        // memset(buf,0,1024);
       }
       if(pid2==0)
       {
        printf("ppid:%d ,pid:%d buf:%s\n",getppid(),getpid(),buf);
        // sprintf(buf,"%d %s\n",getpid(),time());
        // write(fd_out,buf,strlen(buf));
        // sleep(1);
        // memset(buf,0,1024);
       }
       if(pid!=0&&pid2==0)
       {
            pid3=fork();
            wait(NULL);  
            printf("ppid:%d ,pid:%d buf:%s\n",getppid(),getpid(),buf);
            // sprintf(buf,"%d %s\n",getpid(),time());
            // write(fd_out,buf,strlen(buf));
            // sleep(1);
            // memset(buf,0,1024);

       }
       if(pid3==0)
       {
            printf("ppid:%d ,pid:%d buf:%s\n",getppid(),getpid(),buf);
            // sprintf(buf,"%d Hello world!\n",getpid());
            // write(fd_out,buf,strlen(buf));
            // sleep(1);
            // memset(buf,0,1024);
       }
    }else{
        //wait pid ,pid2
        wait(pid);
        wait(pid2);
        printf("parent ppid:%d ,pid:%d buf:%s\n",getppid(),getpid(),buf);
        // sprintf(buf,"%d %s\n",getpid(),time());
        // write(fd_out,buf,strlen(buf));
        // sleep(1);
        // memset(buf,0,1024);
        return 0;
    }
    return 0;
}