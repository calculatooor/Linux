#include "ch09.h"
int main()
{
    pid_t pid[8];
    printf("parent ppid:%d pid:%d\n",getppid(),getpid());//1
    
    if(!(pid[2]=fork())) //2
    {
        printf("ppid:%d pid:%d\n",getppid(),getpid());
    }
    if(pid[2])
    {
        if(!(pid[3]=fork()))//3
        {
            printf("ppid:%d pid:%d\n",getppid(),getpid());
        }
    }
    if(pid[2]&&pid[3])//stop 1
    {
        wait(NULL);
        wait(NULL);
        return 0;
    }

    
}