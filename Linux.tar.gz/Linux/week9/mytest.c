#include "ch09.h"
int main(int argc,char *argv[])
{
    int i;
    extern char **environ;
    char **env=environ;
    for(i=0;i<argc;i++)
    {
        printf("%s\n",argv[i]);
        
    }
    while(*env)
    {
        printf("env : %s\n",*env);
        env++;
    }
    return 0;
}