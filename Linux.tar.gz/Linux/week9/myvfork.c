#include "ch09.h"
int g=9;
int main()
{
    pid_t pid;
    int l=99;
    pid=vfork();
    if(pid<0)
    {
        perror("Fork failed!\n");
        exit(-1);
    }else if(pid==0){
        // sleep(1);
       printf("child : ppid =%d, pid=%d\n",getppid(),getpid());
       printf("child :init g =%d, l=%d\n",g,l);
       g++;
        l--;
       printf("child : g =%d, l=%d\n",g,l);
    //   _exit(1);
    return 0;
    
    }else{
        // wait(pid);
        printf("parent : ppid =%d, pid=%d\n",getppid(),getpid());
        printf("parent :init g =%d, l=%d\n",g,l);
        g++;
        l--;
        printf("parent : g =%d, l=%d\n",g,l);
        return 0;
    }
}