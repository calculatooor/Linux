#include "ch09.h"

int main()
{
    
    pid_t pid=1,pid2=1,pid3=1,pid4;
    pid=fork();
    pid2=fork();
    if(pid==0||pid2==0)
    printf("ppid:%d ,pid:%d\n",getppid(),getpid());
    else{
        wait(NULL);
        wait(NULL);
        printf("parent ppid:%d ,pid:%d\n",getppid(),getpid());
    }
    
    // printf("%d\n",time());

}